System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Input, input, Vec3, Animation, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, PlayerController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Input = _cc.Input;
      input = _cc.input;
      Vec3 = _cc.Vec3;
      Animation = _cc.Animation;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "eed3ajhKdVOyacMhfEROwN8", "PlayerController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Input', 'input', 'Node', 'Vec3', 'Animation']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PlayerController", PlayerController = (_dec = ccclass('PlayerController'), _dec2 = property({
        type: Animation
      }), _dec(_class = (_class2 = class PlayerController extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "BodyAnim", _descriptor, this);

          // 是否收到跳跃指令
          this._startJump = false;
          // 跳跃步长
          this._jumpStep = 0;
          // 当前跳跃时间
          this._curJumpTime = 0;
          // 每次跳跃时长
          this._jumpTime = 0.1;
          // 当前跳跃速度
          this._curJumpSpeed = 0;
          // 当前角色位置
          this._curPos = new Vec3();
          // 角色目标位置
          this._targetPos = new Vec3();
          // 每次跳跃过程中，当前帧移动位置差
          this._deltaPos = new Vec3(0, 0, 0);
        }

        start() {
          input.on(Input.EventType.MOUSE_UP, this.onMouseUp, this);
        }

        update(deltaTime) {
          if (this._startJump) {
            this._curJumpTime += deltaTime;

            if (this._curJumpTime > this._jumpTime) {
              // 跳跃结束
              this.node.setPosition(this._targetPos);
              this._startJump = false;
            } else {
              this.node.getPosition(this._curPos);
              this._deltaPos.x = this._curJumpSpeed * this._curJumpTime;
              Vec3.add(this._curPos, this._curPos, this._deltaPos);
              this.node.setPosition(this._curPos);
            }
          }
        }

        onMouseUp(event) {
          console.log(event);

          if (event.getButton() === 0) {
            this.jumpByStep(1);
          } else if (event.getButton() === 1) {
            this.jumpByStep(2);
          }
        }

        jumpByStep(step) {
          if (this._startJump) {
            return;
          }

          this._startJump = true;
          this._jumpStep = step;
          this._curJumpTime = 0; // 重置下跳跃时间

          this._curJumpSpeed = this._jumpStep / this._jumpTime;
          this.node.getPosition(this._curPos); // 目标位置

          Vec3.add(this._targetPos, this._curPos, new Vec3(this._jumpStep, 0, 0));

          if (this.BodyAnim) {
            if (step === 1) {
              this.BodyAnim.play('oneStep');
            } else if (step === 2) {
              this.BodyAnim.play('twoStep');
            }
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "BodyAnim", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=98ac408b7fccf7111d1aeb80f2dbbfb639cf7784.js.map