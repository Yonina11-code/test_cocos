System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///E:/cocos/cocos-tutrial-mind-your-step/assets/Scripts/PlayerController.ts at runtime.
      throw new Error("SyntaxError: D:Program FilesCocosDashboard_2.1.2\file:E:cocoscocos-tutrial-mind-your-stepassetsScriptsPlayerController.ts: Unexpected token (76:0)\n\n  74 |     }\n  75 |     }\n> 76 | }\n     | ^\n  77 |\n  78 |\n  79 |");
    }
  };
});
//# sourceMappingURL=79d854d9741513a5f37c30df6ad320ab2e679e4f.js.map