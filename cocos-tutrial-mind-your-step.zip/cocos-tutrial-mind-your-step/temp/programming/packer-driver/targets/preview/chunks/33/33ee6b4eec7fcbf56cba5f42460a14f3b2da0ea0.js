System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///E:/cocos/cocos-tutrial-mind-your-step/assets/Scripts/PlayerController.ts at runtime.
      throw new Error("SyntaxError: D:Program FilesCocosDashboard_2.1.2\file:E:cocoscocos-tutrial-mind-your-stepassetsScriptsPlayerController.ts: Unexpected token (70:0)\n\n  68 |       }\n  69 |     }\n> 70 | }\n     | ^\n  71 |\n  72 |\n  73 |");
    }
  };
});
//# sourceMappingURL=33ee6b4eec7fcbf56cba5f42460a14f3b2da0ea0.js.map