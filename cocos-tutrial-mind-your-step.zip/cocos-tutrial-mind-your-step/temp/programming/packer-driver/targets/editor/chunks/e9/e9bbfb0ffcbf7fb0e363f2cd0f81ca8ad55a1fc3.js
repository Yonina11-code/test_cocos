System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///E:/cocos/cocos-tutrial-mind-your-step/assets/Scripts/PlayerController.ts at runtime.
      throw new Error(`SyntaxError: D:\Program Files\CocosDashboard_2.1.2\file:\E:\cocos\cocos-tutrial-mind-your-step\assets\Scripts\PlayerController.ts: Unexpected token (70:0)

  68 |       }
  69 |     }
> 70 | }
     | ^
  71 |
  72 |
  73 |`);
    }
  };
});
//# sourceMappingURL=e9bbfb0ffcbf7fb0e363f2cd0f81ca8ad55a1fc3.js.map