System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///E:/cocos/cocos-tutrial-mind-your-step/assets/Scripts/PlayerController.ts at runtime.
      throw new Error(`SyntaxError: D:\Program Files\CocosDashboard_2.1.2\file:\E:\cocos\cocos-tutrial-mind-your-step\assets\Scripts\PlayerController.ts: Unexpected token (76:0)

  74 |     }
  75 |     }
> 76 | }
     | ^
  77 |
  78 |
  79 |`);
    }
  };
});
//# sourceMappingURL=6f9f773260f9e037c98466f0d1e7e0c06f8289fc.js.map